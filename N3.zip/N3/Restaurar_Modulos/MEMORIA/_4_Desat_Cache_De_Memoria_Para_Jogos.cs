﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.MEMORIA
{
    internal class _4_Desat_Cache_De_Memoria_Para_Jogos
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management", true))
                {
                    if (key != null)
                    {
                        key.DeleteValue("IoPageLockLimit", false); // false: não lançar exceção se não existir
                        Console.WriteLine("IoPageLockLimit removido com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao remover o IoPageLockLimit: " + ex.Message);
            }
        }
    }
}
