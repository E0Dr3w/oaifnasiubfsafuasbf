﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Modulos.MEMORIA
{
    internal class _2_Desat_Cache_Grande
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("LargeSystemCache", 0, RegistryValueKind.DWord);
                        Console.WriteLine("Cache grande desativado com sucesso (LargeSystemCache = 0).");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("Permissão negada. Execute o programa como administrador.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }
    }
}