﻿using Microsoft.Win32;
using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.PRIVACIDADE
{
    internal class _2_Ativ_Serv_De_Localizaçao
    {
        public static void Executar()
        {
            try
            {
                Console.WriteLine("[*] Reativando serviço de localização...");

                ExecutarComando("sc config lfsvc start= demand");
                ExecutarComando("sc start lfsvc");

                Console.WriteLine("[*] Restaurando acesso à localização no registro...");

                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location",
                    "Value", "Allow", RegistryValueKind.String
                );

                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\lfsvc\TriggerInfo\3",
                    "Enabled", 1, RegistryValueKind.DWord
                );

                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors",
                    "DisableLocation", 0, RegistryValueKind.DWord
                );

                Console.WriteLine("[*] Localização restaurada com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[X] Erro ao restaurar localização: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c " + comando)
            {
                CreateNoWindow = true,
                UseShellExecute = false
            };
            Process.Start(psi)?.WaitForExit();
        }
    }
}
