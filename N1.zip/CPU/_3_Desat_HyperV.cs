﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.CPU
{
    internal class _3_Desat_HyperV
    {
        public static void Executar()
        {
            try
            {
                ExecuteCommand("bcdedit /set hypervisorlaunchtype off");
                Console.WriteLine("Hyper-V desativado com sucesso. Reinicie o computador para aplicar as mudanças.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar Hyper-V: {ex.Message}");
            }
        }

        private static void ExecuteCommand(string command)
        {
            var process = new Process();
            process.StartInfo.FileName = "cmd.exe";
            process.StartInfo.Arguments = "/c " + command;
            process.StartInfo.RedirectStandardOutput = false;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.CreateNoWindow = true;

            process.Start();
            process.WaitForExit();
        }
    }
}