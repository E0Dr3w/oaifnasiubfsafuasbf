﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicativos_de_modulos_para_Devs.Modulos.PRIVACIDADE
{
    internal class _3_Desat_Conta_Sync
    {
        public static void Executar()
        {
            try
            {
                Console.WriteLine("[*] Bloqueando login com conta Microsoft...");

                // Bloquear uso de conta Microsoft para login
                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
                    "NoConnectedUser", 3, RegistryValueKind.DWord
                );

                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
                    "BlockConnectedAccount", 1, RegistryValueKind.DWord
                );

                Console.WriteLine("[*] Desativando sincronização com a nuvem...");

                // Bloquear sincronização de configurações
                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\SettingSync",
                    "DisableSettingSync", 2, RegistryValueKind.DWord
                );

                Console.WriteLine("[*] Conta Microsoft e sincronização desativadas.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[X] Erro ao aplicar políticas de conta Microsoft: {ex.Message}");
            }
        }
    }
}