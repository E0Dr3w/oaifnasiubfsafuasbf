﻿using System;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace Aplicativos_de_modulos_para_Devs.Modulos.CPU
{
    internal class _1_Ativ_Desempenho_Max
    {
        public static void Executar()
        {
            const string baseGuid = "e9a42b02-d5df-448d-aa00-03f14749eb61";
            var duplicatedGuid = ExtractGuid(ExecuteWithOutput($"powercfg -duplicatescheme {baseGuid}"));

            if (!string.IsNullOrEmpty(duplicatedGuid))
            {
                Execute($"powercfg /setactive {duplicatedGuid}");
                Console.WriteLine($"Plano 'Desempenho Máximo' ativado com sucesso: {duplicatedGuid}");
            }
            else
            {
                Console.WriteLine("Falha ao ativar o plano de energia.");
            }

            Console.ReadKey();
        }

        private static string ExecuteWithOutput(string cmd)
        {
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {cmd}",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };

            process.Start();
            var output = process.StandardOutput.ReadToEnd();
            process.WaitForExit();
            return output;
        }

        private static void Execute(string cmd)
        {
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {cmd}",
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };

            process.Start();
            process.WaitForExit();
        }

        private static string ExtractGuid(string text)
        {
            var match = Regex.Match(text, @"([a-fA-F0-9]{8}(-[a-fA-F0-9]{4}){3}-[a-fA-F0-9]{12})");
            return match.Success ? match.Value : null;
        }
    }
}