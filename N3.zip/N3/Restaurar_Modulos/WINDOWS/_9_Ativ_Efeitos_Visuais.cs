﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _9_Ativ_Efeitos_Visuais
    {
        public static void Executar()
        {
            try
            {
                // Define VisualFXSetting para 1 (ativar efeitos padrão)
                ExecutarComando(@"reg add ""HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"" /v VisualFXSetting /t REG_DWORD /d 1 /f");
                // Define UserPreferencesMask para ativar efeitos padrão (exemplo, pode variar)
                ExecutarComando(@"reg add ""HKCU\Control Panel\Desktop"" /v UserPreferencesMask /t REG_BINARY /d 90120000010000000000000000 /f");
                // Define MinAnimate para 1 (ativa animação minimizar/maximizar)
                ExecutarComando(@"reg add ""HKEY_CURRENT_USER\Control Panel\Desktop\WindowMetrics"" /v MinAnimate /t REG_SZ /d 1 /f");

                Console.WriteLine("Efeitos visuais ativados com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ativar efeitos visuais: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
