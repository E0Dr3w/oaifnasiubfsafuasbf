﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _32_Desat_Recurso_Grafico_Nao_Utilizados
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("VisualFXSetting", "2", RegistryValueKind.String);
                        Console.WriteLine("Configuração VisualFXSetting definida para 2 (desativar recursos gráficos não utilizados).");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao alterar VisualFXSetting: " + ex.Message);
            }
        }
    }
}
