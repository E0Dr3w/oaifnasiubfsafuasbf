﻿using Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.PRIVACIDADE;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos
{
    internal class Res_PRIVACIDADE
    {
        public static void Executar()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Restauração MEMORIA ===");
                Console.WriteLine("1 - Ativar telemetria");
                Console.WriteLine("2 - Ativar Serviço de localizaçao");
                Console.WriteLine("3 - Ativar Conta da Microsoft");
                Console.WriteLine("4 - Ativar Windows Updates");
                Console.WriteLine("5 - Ativar Serviços de Rede que coleta Dados");
                Console.WriteLine("0 - Voltar");

                Console.Write("Escolha uma opção: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        _1_Ativ_Telemetria.Executar();
                        break;

                    case "2":
                        _2_Ativ_Serv_De_Localizaçao.Executar();
                        break;

                    case "3":
                        _3_Ativ_Conta_E_Sync.Executar();
                        break;

                    case "4":
                        _4_Ativ_Win_Update.Executar();
                        break;

                    case "5":
                        _5_Ativ_Serviços_De_Rede_Que_Coletam_Dados.Executar();
                        break;

                    case "0":
                        return;

                    default:
                        Console.WriteLine("Opção inválida! Pressione qualquer tecla para tentar novamente.");
                        break;
                }

                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }
    }
}
