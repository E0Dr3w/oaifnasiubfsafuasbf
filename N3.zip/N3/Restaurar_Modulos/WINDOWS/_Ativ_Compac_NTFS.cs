﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _Ativ_Compac_NTFS
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\FileSystem", true))
                {
                    if (key != null)
                    {
                        key.SetValue("NtfsDisableCompression", 0, RegistryValueKind.DWord);
                        Console.WriteLine("Compactação NTFS restaurada ao padrão (ativa).");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao restaurar compactação NTFS: " + ex.Message);
            }
        }
    }
}
