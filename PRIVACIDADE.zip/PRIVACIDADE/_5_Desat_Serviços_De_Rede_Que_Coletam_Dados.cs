﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicativos_de_modulos_para_Devs.Modulos.PRIVACIDADE
{
    internal class _5_Desat_Serviços_De_Rede_Que_Coletam_Dados
    {
        public static void Executar()
        {
            try
            {
                Console.WriteLine("[*] Desativando serviços de rede invasivos...");

                string[] servicos = {
                    "WdiServiceHost",
                    "WdiSystemHost",
                    "WinRM",
                    "RemoteRegistry",
                    "NetTcpPortSharing",
                    "RemoteAccess",
                    "SharedAccess",
                    "DoSvc" // Delivery Optimization
                };

                foreach (var servico in servicos)
                {
                    ExecutarComando($"sc stop {servico}");
                    ExecutarComando($"sc config {servico} start= disabled");
                }

                Console.WriteLine("[*] Serviços de rede desativados com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[X] Erro ao desativar serviços de rede: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c " + comando)
            {
                CreateNoWindow = true,
                UseShellExecute = false
            };
            Process.Start(psi)?.WaitForExit();
        }
    }
}