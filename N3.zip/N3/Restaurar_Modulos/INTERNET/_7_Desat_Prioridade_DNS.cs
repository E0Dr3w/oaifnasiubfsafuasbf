﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.INTERNET
{
    internal class _7_Desat_Prioridade_DNS
    {
        public static void Executar()
        {
            try
            {
                string[] comandos = new string[]
                {
                    // Removendo os valores ou colocando defaults básicos
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\DNS\Parameters"" /v MaximumUdpPacketSize /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\DNScache\Parameters"" /v CacheHashTableBucketSize /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v CacheHashTableSize /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v DefaultTTL /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v DynamicBacklogGrowthDelta /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v EnableAutoDoh /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v EnableDynamicBacklog /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v extension /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaxCacheEntryTtlLimit /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaxCacheTtl /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaximumDynamicBacklog /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaximumUdpPacketSize /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaxNegativeCacheTtl /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaxSOACacheEntryTtlLimit /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MinimumDynamicBacklog /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MouseSensitivity /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v NegativeCacheTime /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v NegativeSOACacheTime /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v NetFailureCacheTime /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v ServerPriorityTimeLimit /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v ServiceDll /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v ServiceDllUnloadOnStop /f",
                    @"REG DELETE ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v TcpNoDelay /f",
                    @"REG DELETE ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v DisableSmartNameResolution /f",
                    @"REG DELETE ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v DisableSmartProtocolReordering /f",
                    @"REG DELETE ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v EnableIdnMapping /f",
                    @"REG DELETE ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v EnableMulticast /f",
                    @"REG DELETE ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v PreferLocalOverLowerBindingDNS /f",
                    @"REG DELETE ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v RegistrationEnabled /f",
                    @"REG DELETE ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v UpdateSecurityLevel /f"
                };

                foreach (var cmd in comandos)
                {
                    ExecutarComando(cmd);
                }

                Console.WriteLine("Configurações de prioridade DNS restauradas para padrão.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao restaurar configurações DNS: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };

            processo.Start();
            string output = processo.StandardOutput.ReadToEnd();
            string error = processo.StandardError.ReadToEnd();
            processo.WaitForExit();

            if (!string.IsNullOrEmpty(error) && !error.Contains("OK."))
                throw new Exception(error);
        }
    }
}
