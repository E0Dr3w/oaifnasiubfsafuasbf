﻿using Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.INTERNET;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos
{
    internal class Res_INTERNET
    {
        public static void Executar()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Restauração INTERNET ===");
                Console.WriteLine("1 - Restaurar Configurações do AFD");
                Console.WriteLine("2 - Ativar Fila TCP");
                Console.WriteLine("3 - Restaurar MTU");
                Console.WriteLine("4 - Desativar Configurações TCP/IP");
                Console.WriteLine("5 - Desativar Fast DNS");
                Console.WriteLine("6 - Ativar Reserva de Banda");
                Console.WriteLine("7 - Desativar Prioridade DNS");
                Console.WriteLine("0 - Voltar");

                Console.Write("Escolha uma opção: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        _1_Res_No_AFD.Executar();
                        break;
                    case "2":
                        _2_Ativar_Fila_TCP.Executar();
                        break;
                    case "3":
                        _3_Res_MTU.Executar();
                        break;
                    case "4":
                        _4_Res_TCP_IP.Executar();
                        break;
                    case "5":
                        _5_Desat_Fast_DNS.Executar();
                        break;
                    case "6":
                        _6_Ativ_Reserva_De_Banda.Executar();
                        break;
                    case "7":
                        _7_Desat_Prioridade_DNS.Executar();
                        break;
                    case "0":
                        return;

                    default:
                        Console.WriteLine("Opção inválida! Pressione qualquer tecla para tentar novamente.");
                        break;
                }

                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }
    }
}