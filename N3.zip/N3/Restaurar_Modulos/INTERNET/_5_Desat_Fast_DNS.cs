﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.INTERNET
{
    internal class _5_Desat_Fast_DNS
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando("ipconfig /flushdns");

                ExecutarComando(@"netsh interface ipv4 set dnsservers name=""Wi-Fi"" source=dhcp");
                ExecutarComando(@"netsh interface ipv4 set dnsservers name=""Ethernet"" source=dhcp");

                Console.WriteLine("DNS restaurado para automático em Wi-Fi e Ethernet.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao restaurar DNS automático: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                }
            };

            processo.Start();
            string output = processo.StandardOutput.ReadToEnd();
            string error = processo.StandardError.ReadToEnd();
            processo.WaitForExit();

            if (!string.IsNullOrEmpty(error) && !error.Contains("OK."))
                throw new Exception(error);
        }
    }
}
