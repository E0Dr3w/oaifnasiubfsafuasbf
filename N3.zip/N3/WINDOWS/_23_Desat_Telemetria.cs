﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _23_Desat_Telemetria
    {
        public static void Executar()
        {
            try
            {
                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DataCollection",
                    "AllowTelemetry",
                    0,
                    RegistryValueKind.DWord
                );

                Console.WriteLine("Telemetria desativada com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar a telemetria: {ex.Message}");
            }
        }
    }
}
