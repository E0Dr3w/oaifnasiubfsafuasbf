﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.INTERNET
{
    internal class _7_Ativ_Prioridade_DNS
    {
        public static void Executar()
        {
            try
            {
                // Lista de comandos REG ADD para aplicar
                string[] comandos = new string[]
                {
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\DNS\Parameters"" /v MaximumUdpPacketSize /t REG_DWORD /d 1398 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\DNScache\Parameters"" /v CacheHashTableBucketSize /t REG_DWORD /d 1 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v CacheHashTableSize /t REG_DWORD /d 384 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v DefaultTTL /t REG_DWORD /d 64 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v DynamicBacklogGrowthDelta /t REG_DWORD /d 256 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v EnableAutoDoh /t REG_DWORD /d 2 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v EnableDynamicBacklog /t REG_DWORD /d 1 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v extension /t REG_EXPAND_SZ /d ""%SystemRoot%\System32\dnsext.dll"" /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaxCacheEntryTtlLimit /t REG_DWORD /d 64000 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaxCacheTtl /t REG_DWORD /d 10800 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaximumDynamicBacklog /t REG_DWORD /d 131072 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaximumUdpPacketSize /t REG_DWORD /d 4864 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaxNegativeCacheTtl /t REG_DWORD /d 0 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MaxSOACacheEntryTtlLimit /t REG_DWORD /d 301 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MinimumDynamicBacklog /t REG_DWORD /d 512 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v MouseSensitivity /t REG_SZ /d 10 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v NegativeCacheTime /t REG_DWORD /d 0 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v NegativeSOACacheTime /t REG_DWORD /d 0 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v NetFailureCacheTime /t REG_DWORD /d 0 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v ServerPriorityTimeLimit /t REG_DWORD /d 0 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v ServiceDll /t REG_EXPAND_SZ /d ""%SystemRoot%\System32\dnsrslvr.dll"" /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v ServiceDllUnloadOnStop /t REG_DWORD /d 1 /f",
                    @"REG ADD ""HKLM\System\CurrentControlSet\Services\Dnscache\Parameters"" /v TcpNoDelay /t REG_DWORD /d 151807 /f",
                    @"REG ADD ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v DisableSmartNameResolution /t REG_DWORD /d 1 /f",
                    @"REG ADD ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v DisableSmartProtocolReordering /t REG_DWORD /d 1 /f",
                    @"REG ADD ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v EnableIdnMapping /t REG_DWORD /d 0 /f",
                    @"REG ADD ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v EnableMulticast /t REG_DWORD /d 0 /f",
                    @"REG ADD ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v PreferLocalOverLowerBindingDNS /t REG_DWORD /d 1 /f",
                    @"REG ADD ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v RegistrationEnabled /t REG_DWORD /d 0 /f",
                    @"REG ADD ""HKLM\Software\Policies\Microsoft\Windows NT\DNSClient"" /v UpdateSecurityLevel /t REG_DWORD /d 0 /f"
                };

                foreach (var cmd in comandos)
                {
                    ExecutarComando(cmd);
                }

                Console.WriteLine("Configurações avançadas de DNS aplicadas com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao aplicar configurações de DNS: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };

            processo.Start();
            string output = processo.StandardOutput.ReadToEnd();
            string error = processo.StandardError.ReadToEnd();
            processo.WaitForExit();

            if (!string.IsNullOrEmpty(error) && !error.Contains("OK."))
                throw new Exception(error);
        }
    }
}
