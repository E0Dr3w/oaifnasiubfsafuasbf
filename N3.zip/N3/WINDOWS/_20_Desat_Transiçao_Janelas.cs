﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _20_Desat_Transiçao_Janelas
    {
        public static void Executar()
        {
            try
            {
                Registry.SetValue(
                    @"HKEY_CURRENT_USER\Control Panel\Desktop",
                    "UserPreferencesMask",
                    new byte[] { 0x90, 0x12, 0x03, 0x80 },
                    RegistryValueKind.Binary
                );

                Console.WriteLine("Transições de janelas desabilitadas.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar transições de janelas: {ex.Message}");
            }
        }
    }
}
