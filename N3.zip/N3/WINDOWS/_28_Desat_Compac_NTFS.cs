﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _28_Desat_Compac_NTFS
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Control\FileSystem"))
                {
                    if (key != null)
                    {
                        key.SetValue("NtfsDisableCompression", 1, RegistryValueKind.DWord);
                        Console.WriteLine("Compactação NTFS desativada com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao desativar compactação NTFS: " + ex.Message);
            }
        }
    }
}
