﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.GPU
{
    internal class _3_Desat_Prioridade_DirectX
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\FileSystem", true))
                {
                    if (key != null)
                    {
                        key.SetValue("NtfsDisableLastAccessUpdate", 0, RegistryValueKind.DWord);
                        Console.WriteLine("Atualização de último acesso reativada (prioridade padrão do sistema restaurada).");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao restaurar prioridade DirectX: " + ex.Message);
            }
        }
    }
}
