﻿using System;
using Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.CPU;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos
{
    internal class Res_CPU
    {
        public static void Executar()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Restauração CPU ===");
                Console.WriteLine("1 - Ativar Intel PPM");
                Console.WriteLine("2 - Ativar Hyper-V");
                Console.WriteLine("3 - Ativar CPU Parking");
                Console.WriteLine("4 - Ativar CPU Throttle");
                Console.WriteLine("0 - Voltar");
                Console.Write("Escolha uma opção: ");

                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        _2_Ativ_Intel_PPM.Executar();
                        break;
                    case "2":
                        _4_Ativ_HyperV.Executar();
                        break;
                    case "3":
                        _4_Ativ_Cpu_Parking.Executar();
                        break;
                    case "4":
                        _5_Ativ_Cpu_Throttle.Executar();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Opção inválida! Pressione qualquer tecla para tentar novamente.");
                        Console.ReadKey();
                        break;
                }

                Console.WriteLine("\nPressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }
    }
}
