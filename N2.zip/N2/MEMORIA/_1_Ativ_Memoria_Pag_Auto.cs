﻿using System;
using System.Management;  // Precisa adicionar referência System.Management

namespace Aplicativos_de_modulos_para_Devs.Modulos.MEMORIA
{
    internal class _1_Ativ_Memoria_Pag_Auto
    {
        public static void Executar()
        {
            try
            {
                // Conectar no WMI na classe Win32_ComputerSystem
                using (var searcher = new ManagementObjectSearcher(
                    "SELECT * FROM Win32_ComputerSystem WHERE Name = '" + Environment.MachineName + "'"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        var inParams = obj.GetMethodParameters("SetAutomaticManagedPagefile");
                        // Definir como true para ativar o gerenciamento automático
                        // Mas método direto SetAutomaticManagedPagefile não existe; usamos SetPropertyValue direto.
                        obj["AutomaticManagedPagefile"] = true;
                        obj.Put();

                        Console.WriteLine("Arquivo de paginação ajustado para automático.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ajustar arquivo de paginação: {ex.Message}");
            }
        }
    }
}
