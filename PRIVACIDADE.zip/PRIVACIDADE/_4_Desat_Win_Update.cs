﻿using Microsoft.Win32;
using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.PRIVACIDADE
{
    internal class _4_Desat_Win_Update
    {
        public static void Executar()
        {
            try
            {
                Console.WriteLine("[*] Parando e desativando serviços do Windows Update...");

                string[] servicos = {
                    "wuauserv",        // Windows Update
                    "UsoSvc",          // Update Orchestrator
                    "BITS",            // Background Intelligent Transfer Service
                    "DoSvc",           // Delivery Optimization
                    "WaaSMedicSvc"     // Update Medic (reativa update mesmo desativado)
                };

                foreach (var servico in servicos)
                {
                    ExecutarComando($"sc stop {servico}");
                    ExecutarComando($"sc config {servico} start= disabled");
                }

                Console.WriteLine("[*] Desativando tarefas agendadas relacionadas...");

                string[] tarefas = {
                    @"Microsoft\Windows\WindowsUpdate\sih",
                    @"Microsoft\Windows\WindowsUpdate\sihboot",
                    @"Microsoft\Windows\UpdateOrchestrator\ScheduleScan",
                    @"Microsoft\Windows\UpdateOrchestrator\USO_UxBroker",
                    @"Microsoft\Windows\UpdateOrchestrator\Reboot",
                    @"Microsoft\Windows\UpdateOrchestrator\ScanInstallWait"
                };

                foreach (var tarefa in tarefas)
                {
                    ExecutarComando($"schtasks /Change /TN \"{tarefa}\" /Disable");
                }

                Console.WriteLine("[*] Aplicando políticas via Registro...");

                // Desativar Windows Update via políticas de grupo
                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU",
                    "NoAutoUpdate", 1, RegistryValueKind.DWord
                );

                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU",
                    "AUOptions", 1, RegistryValueKind.DWord // Nunca verificar atualizações
                );

                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate",
                    "DisableWindowsUpdateAccess", 1, RegistryValueKind.DWord
                );

                Console.WriteLine("[*] Windows Update desativado com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[X] Erro ao desativar Windows Update: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c " + comando)
            {
                CreateNoWindow = true,
                UseShellExecute = false
            };
            Process.Start(psi)?.WaitForExit();
        }
    }
}