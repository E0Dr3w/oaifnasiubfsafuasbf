﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _29_Ativ_Download_Maps
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\MapsBroker", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("Start", 3, RegistryValueKind.DWord); // 3 = manual (padrão comum)
                        Console.WriteLine("Serviço MapsBroker restaurado para manual.");
                    }
                    else
                    {
                        Console.WriteLine("Chave MapsBroker não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao restaurar MapsBroker: " + ex.Message);
            }
        }
    }
}
