﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _10_Desat_Hibernaçao
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando("powercfg -h off");
                Console.WriteLine("Hibernação desabilitada com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desabilitar hibernação: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
