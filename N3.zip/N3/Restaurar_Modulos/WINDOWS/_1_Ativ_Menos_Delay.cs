﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _1_Ativ_Menos_Delay
    {
        public static void Executar()
        {
            // Restaura MenuShowDelay e os tempos de espera no usuário atual
            try
            {
                using (RegistryKey keyUser = Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop", writable: true))
                {
                    if (keyUser != null)
                    {
                        keyUser.SetValue("MenuShowDelay", "400", RegistryValueKind.String);
                        keyUser.SetValue("WaitToKillAppTimeout", "5000", RegistryValueKind.String);
                        keyUser.SetValue("HungAppTimeout", "5000", RegistryValueKind.String);

                        Console.WriteLine("Configurações do desktop restauradas para os valores padrão.");
                    }
                    else
                    {
                        Console.WriteLine("Erro ao acessar HKCU\\Control Panel\\Desktop");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao restaurar configurações do desktop: {ex.Message}");
            }

            // Restaura WaitToKillServiceTimeout no sistema
            try
            {
                using (RegistryKey keyMachine = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control", writable: true))
                {
                    if (keyMachine != null)
                    {
                        keyMachine.SetValue("WaitToKillServiceTimeout", "5000", RegistryValueKind.String);
                        // Opcional: restaurar LastBootSucceeded e LastBootShutdown se desejar
                        keyMachine.SetValue("LastBootSucceeded", 1, RegistryValueKind.DWord);
                        keyMachine.SetValue("LastBootShutdown", 1, RegistryValueKind.DWord);

                        Console.WriteLine("Chaves do registro HKLM\\SYSTEM\\CurrentControlSet\\Control restauradas com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Erro ao acessar HKLM\\SYSTEM\\CurrentControlSet\\Control");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao restaurar chaves HKLM: {ex.Message}");
            }
        }
    }
}
