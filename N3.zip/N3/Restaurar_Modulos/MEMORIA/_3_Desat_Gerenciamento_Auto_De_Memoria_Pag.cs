﻿using System;
using System.Management;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.MEMORIA
{
    internal class _3_Desat_Gerenciamento_Auto_De_Memoria_Pag
    {
        public static void Executar()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_ComputerSystem WHERE Name = \"" + Environment.MachineName + "\""))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        var inParams = obj.GetMethodParameters("SetAutomaticManagedPagefile");
                        inParams["AutomaticManagedPagefile"] = false;

                        var outParams = obj.InvokeMethod("SetAutomaticManagedPagefile", inParams, null);
                        uint ret = (uint)outParams.Properties["ReturnValue"].Value;

                        if (ret == 0)
                        {
                            Console.WriteLine("Gerenciamento automático do arquivo de paginação desativado com sucesso.");
                        }
                        else
                        {
                            Console.WriteLine($"Falha ao desativar. Código de retorno: {ret}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }
    }
}
