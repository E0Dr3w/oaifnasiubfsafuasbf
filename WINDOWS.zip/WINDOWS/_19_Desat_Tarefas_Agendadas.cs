﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _19_Desat_Tarefas_Agendadas
    {
        public static void Executar()
        {
            string[] tarefas = new string[]
            {
                @"Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
                @"Microsoft\Windows\Application Experience\ProgramDataUpdater",
                @"Microsoft\Windows\Autochk\Proxy",
                @"Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"
            };

            foreach (var tarefa in tarefas)
            {
                try
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = "schtasks",
                        Arguments = $"/Change /TN \"{tarefa}\" /Disable",
                        UseShellExecute = false,
                        CreateNoWindow = true
                    })?.WaitForExit();
                    Console.WriteLine($"Tarefa desativada: {tarefa}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao desativar '{tarefa}': {ex.Message}");
                }
            }
        }
    }
}
