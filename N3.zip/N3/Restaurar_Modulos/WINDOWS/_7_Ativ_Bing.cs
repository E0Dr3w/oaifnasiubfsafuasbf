﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _7_Ativ_Bing
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando(@"reg add ""HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search"" /v BingSearchEnabled /t REG_DWORD /d 1 /f");
                ExecutarComando(@"reg add ""HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search"" /v CortanaEnabled /t REG_DWORD /d 1 /f");

                Console.WriteLine("Bing e Cortana ativados com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ativar Bing e Cortana: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
