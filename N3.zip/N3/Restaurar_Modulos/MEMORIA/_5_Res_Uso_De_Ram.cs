﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.MEMORIA
{
    internal class _5_Restaurar_Uso_De_Ram
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("ClearPageFileAtShutdown", 0, RegistryValueKind.DWord);
                        key.SetValue("LargeSystemCache", 0, RegistryValueKind.DWord);
                        key.SetValue("DisablePagingExecutive", 0, RegistryValueKind.DWord);
                        key.SetValue("SecondLevelDataCache", 0, RegistryValueKind.DWord);

                        Console.WriteLine("Configurações de memória restauradas para padrão.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao restaurar configurações de memória: " + ex.Message);
            }
        }
    }
}
