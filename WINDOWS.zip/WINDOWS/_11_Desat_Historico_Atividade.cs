﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _11_Desat_Historico_Atividade
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando(@"reg add ""HKLM\SOFTWARE\Policies\Microsoft\Windows\System"" /v PublishUserActivities /t REG_DWORD /d 0 /f");
                Console.WriteLine("Histórico de atividades desativado com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar histórico de atividades: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
