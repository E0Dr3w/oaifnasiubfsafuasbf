﻿using System;
using Microsoft.Win32;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.PRIVACIDADE
{
    internal class _1_Ativ_Telemetria
    {
        public static void Executar()
        {
            try
            {
                Console.WriteLine("[*] Restaurando serviços de telemetria...");

                // Ativar e iniciar serviços
                string[] servicos = { "DiagTrack", "dmwappushsvc" };
                foreach (string servico in servicos)
                {
                    ExecutarComando($"sc config {servico} start= auto");
                    ExecutarComando($"sc start {servico}");
                }

                Console.WriteLine("[*] Restaurando nível padrão de diagnóstico no registro...");

                // Nível 2 = Básico (nível padrão para maioria das edições)
                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DataCollection",
                    "AllowTelemetry", 2, RegistryValueKind.DWord
                );

                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection",
                    "AllowTelemetry", 2, RegistryValueKind.DWord
                );

                Console.WriteLine("[*] Reativando tarefas agendadas de telemetria...");

                string[] tarefas = {
                    @"Microsoft\Windows\Application Experience\ProgramDataUpdater",
                    @"Microsoft\Windows\Autochk\Proxy",
                    @"Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
                    @"Microsoft\Windows\Customer Experience Improvement Program\UsbCeip",
                    @"Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"
                };

                foreach (string tarefa in tarefas)
                {
                    ExecutarComando($"schtasks /Change /TN \"{tarefa}\" /Enable");
                }

                Console.WriteLine("[*] Telemetria restaurada com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[X] Erro ao restaurar telemetria: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c " + comando)
            {
                CreateNoWindow = true,
                UseShellExecute = false
            };
            Process.Start(psi)?.WaitForExit();
        }
    }
}