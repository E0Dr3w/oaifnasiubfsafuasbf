﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.GPU
{
    internal class _2_Ativ_Reduçao_Taxa_De_Atualizaçoes
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\DWM", true))
                {
                    if (key != null)
                    {
                        key.DeleteValue("EnableUserDWM", false); // false: não lança erro se não existir
                        Console.WriteLine("Redução de taxa de atualizações restaurada ao padrão.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao restaurar a redução de taxa de atualizações: " + ex.Message);
            }
        }
    }
}
