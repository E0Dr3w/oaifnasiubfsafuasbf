﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _28_Ativ_Compac_NTFS
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\FileSystem", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("NtfsDisableCompression", 0, RegistryValueKind.DWord);
                        Console.WriteLine("Compressão NTFS ativada (padrão).");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao ativar compressão NTFS: " + ex.Message);
            }
        }
    }
}
