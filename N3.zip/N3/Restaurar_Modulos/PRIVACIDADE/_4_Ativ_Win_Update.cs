﻿using Microsoft.Win32;
using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.PRIVACIDADE
{
    internal class _4_Ativ_Win_Update
    {
        public static void Executar()
        {
            try
            {
                Console.WriteLine("[*] Reativando serviços do Windows Update...");

                string[] servicos = {
                    "wuauserv",        // Windows Update
                    "UsoSvc",          // Update Orchestrator
                    "BITS",            // Background Intelligent Transfer Service
                    "DoSvc",           // Delivery Optimization
                    "WaaSMedicSvc"     // Update Medic
                };

                foreach (var servico in servicos)
                {
                    ExecutarComando($"sc config {servico} start= demand");
                    ExecutarComando($"sc start {servico}");
                }

                Console.WriteLine("[*] Reativando tarefas agendadas...");

                string[] tarefas = {
                    @"Microsoft\Windows\WindowsUpdate\sih",
                    @"Microsoft\Windows\WindowsUpdate\sihboot",
                    @"Microsoft\Windows\UpdateOrchestrator\ScheduleScan",
                    @"Microsoft\Windows\UpdateOrchestrator\USO_UxBroker",
                    @"Microsoft\Windows\UpdateOrchestrator\Reboot",
                    @"Microsoft\Windows\UpdateOrchestrator\ScanInstallWait"
                };

                foreach (var tarefa in tarefas)
                {
                    ExecutarComando($"schtasks /Change /TN \"{tarefa}\" /Enable");
                }

                Console.WriteLine("[*] Removendo bloqueios no registro...");

                // Remove políticas que impedem o Windows Update
                RegistryKey keyAU = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU", writable: true);
                if (keyAU != null)
                {
                    keyAU.DeleteValue("NoAutoUpdate", false);
                    keyAU.DeleteValue("AUOptions", false);
                    keyAU.Close();
                }

                RegistryKey keyWU = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate", writable: true);
                if (keyWU != null)
                {
                    keyWU.DeleteValue("DisableWindowsUpdateAccess", false);
                    keyWU.Close();
                }

                Console.WriteLine("[*] Windows Update restaurado com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[X] Erro ao restaurar Windows Update: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c " + comando)
            {
                CreateNoWindow = true,
                UseShellExecute = false
            };
            Process.Start(psi)?.WaitForExit();
        }
    }
}