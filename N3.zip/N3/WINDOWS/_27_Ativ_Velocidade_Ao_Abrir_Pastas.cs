﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _27_Ativ_Velocidade_Ao_Abrir_Pastas
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Control\FileSystem"))
                {
                    if (key != null)
                    {
                        key.SetValue("NtfsDisableLastAccessUpdate", 1, RegistryValueKind.DWord);
                        Console.WriteLine("Velocidade ao abrir pastas foi otimizada com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao aplicar otimização de abertura de pastas: " + ex.Message);
            }
        }
    }
}
