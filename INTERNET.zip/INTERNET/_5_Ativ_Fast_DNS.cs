﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.INTERNET
{
    internal class _5_Ativ_Fast_DNS
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando("ipconfig /flushdns");

                ExecutarComando(@"netsh interface ipv4 set dnsservers name=""Wi-Fi"" static 8.8.8.8");
                ExecutarComando(@"netsh interface ipv4 add dnsservers name=""Wi-Fi"" 8.8.4.4 index=2");

                ExecutarComando(@"netsh interface ipv4 set dnsservers name=""Ethernet"" static 8.8.8.8");
                ExecutarComando(@"netsh interface ipv4 add dnsservers name=""Ethernet"" 8.8.4.4 index=2");

                Console.WriteLine("DNS do Google configurado para Wi-Fi e Ethernet.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao configurar DNS rápido: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                }
            };

            processo.Start();
            string output = processo.StandardOutput.ReadToEnd();
            string error = processo.StandardError.ReadToEnd();
            processo.WaitForExit();

            if (!string.IsNullOrEmpty(error) && !error.Contains("OK."))
                throw new Exception(error);
        }
    }
}
