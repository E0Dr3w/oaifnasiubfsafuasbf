﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _21_Ativ_Transparencia
    {
        public static void Executar()
        {
            try
            {
                Registry.SetValue(
                    @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize",
                    "EnableTransparency",
                    1,
                    RegistryValueKind.DWord
                );

                Console.WriteLine("Transparência ativada.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ativar transparência: {ex.Message}");
            }
        }
    }
}
