﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _31_Ativ_Limpe_De_Disco_Auto
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("NoAutoClean", 0, RegistryValueKind.DWord);
                        Console.WriteLine("Limpeza automática de disco ativada (padrão).");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao ativar limpeza automática de disco: " + ex.Message);
            }
        }
    }
}
