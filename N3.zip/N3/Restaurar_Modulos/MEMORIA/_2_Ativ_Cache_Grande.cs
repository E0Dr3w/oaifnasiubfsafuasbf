﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.MEMORIA
{
    internal class _2_Ativ_Cache_Grande
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("LargeSystemCache", 1, RegistryValueKind.DWord);
                        Console.WriteLine("Cache grande ativado com sucesso (LargeSystemCache = 1).");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("Permissão negada. Execute o programa como administrador.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }
    }
}