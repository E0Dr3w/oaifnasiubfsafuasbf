﻿using Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.HDD;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos
{
    internal class Res_HDD
    {
        public static void Executar()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Restauração HDD ===");
                Console.WriteLine("1 - Restaurar Tempo de Atividade do Disco");
                Console.WriteLine("2 - Restaurar Atualização do Último Acesso");
                Console.WriteLine("3 - Restaurar Indexação do Windows");
                Console.WriteLine("0 - Voltar");

                Console.Write("Escolha uma opção: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        _1_Ativ_Tempo_De_Atividade_Do_Disco.Executar();
                        break;

                    case "2":
                        _2_Ativ_Ultimo_Acesso.Executar();
                        break;

                    case "3":
                        _3_Ativ_Indexaçao.Executar();
                        break;

                    case "0":
                        return;

                    default:
                        Console.WriteLine("Opção inválida! Pressione qualquer tecla para tentar novamente.");
                        break;
                }

                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }
    }
}
