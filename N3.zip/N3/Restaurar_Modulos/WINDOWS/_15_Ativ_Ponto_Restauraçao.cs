﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _15_Ativ_Ponto_Restauraçao
    {
        public static void Executar()
        {
            try
            {
                // Ajusta shadowstorage para 10% do disco C: (padrão razoável)
                ExecutarComando("vssadmin resize shadowstorage /for=C: /on=C: /maxsize=10%");
                Console.WriteLine("Serviços de sombra ativados com tamanho padrão.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ativar serviços de sombra: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
