﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _18_Desat_Sugestoes_Pesquisas
    {
        public static void Executar()
        {
            try
            {
                Registry.SetValue(
                    @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search",
                    "SearchHistoryEnabled",
                    0,
                    RegistryValueKind.DWord
                );

                Console.WriteLine("Sugestões de pesquisa desativadas com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar sugestões: {ex.Message}");
            }
        }
    }
}
