﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.HDD
{
    internal class _1_Ativ_Tempo_De_Atividade_Do_Disco
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando("powercfg /change disk-timeout-ac 1");
                ExecutarComando("powercfg /change disk-timeout-dc 1");
                Console.WriteLine("Timeout do disco restaurado para 5 minutos (modo AC e DC).");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao restaurar timeout do disco: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };

            processo.Start();
            string output = processo.StandardOutput.ReadToEnd();
            string error = processo.StandardError.ReadToEnd();
            processo.WaitForExit();

            if (!string.IsNullOrEmpty(error))
                throw new Exception(error);
        }
    }
}