﻿using System;
using System.ServiceProcess;
using System.Management;

namespace Aplicativos_de_modulos_para_Devs.Modulos.HDD
{
    internal class _3_Desat_Indexaçao
    {
        public static void Executar()
        {
            try
            {
                string serviceName = "WSearch";

                // Parar o serviço
                using (ServiceController sc = new ServiceController(serviceName))
                {
                    if (sc.Status != ServiceControllerStatus.Stopped &&
                        sc.Status != ServiceControllerStatus.StopPending)
                    {
                        Console.WriteLine("Parando serviço de indexação...");
                        sc.Stop();
                        sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(10));
                        Console.WriteLine("Serviço parado.");
                    }
                    else
                    {
                        Console.WriteLine("Serviço já está parado.");
                    }
                }

                // Desabilitar o serviço (start = disabled)
                using (ManagementObject service = new ManagementObject($"Win32_Service.Name='{serviceName}'"))
                {
                    var inParams = service.GetMethodParameters("ChangeStartMode");
                    inParams["StartMode"] = "Disabled";
                    var outParams = service.InvokeMethod("ChangeStartMode", inParams, null);
                    uint ret = (uint)outParams.Properties["ReturnValue"].Value;

                    if (ret == 0)
                    {
                        Console.WriteLine("Serviço desabilitado com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine($"Falha ao desabilitar o serviço. Código: {ret}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }
    }
}