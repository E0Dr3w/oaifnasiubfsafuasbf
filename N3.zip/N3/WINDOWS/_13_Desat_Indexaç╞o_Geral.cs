﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _13_Desat_Indexação_Geral
    {
        public static void Executar()
        {
            try
            {
                // Desativar Indexação Geral
                ExecutarComando("sc stop WSearch");
                ExecutarComando("sc config WSearch start= disabled");

                // Opcional: Desativar serviço de Pesquisa da Windows Push Notification (pode afetar notificações)
                ExecutarComando("sc stop WpnUserService");
                ExecutarComando("sc config WpnUserService start= disabled");

                // Você pode adicionar mais serviços aqui conforme necessário

                Console.WriteLine("Indexação geral e serviços relacionados desativados com sucesso!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar indexação geral: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
