﻿using Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos
{
    internal class Res_WINDOWS
    {
        public static void Executar()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Restauração - WINDOWS ===");
                Console.WriteLine("1 - Restaurar Delay padrão do Menu (MenuShowDelay)");
                Console.WriteLine("2 - Ativar Windows Defender");
                Console.WriteLine("3 - Ativar Controle de Conta de Usuário (UAC)");
                Console.WriteLine("4 - Ativar animação de minimizar/maximizar janelas");
                Console.WriteLine("5 - Ativar animações do sistema");
                Console.WriteLine("6 - Ativar atualizações automáticas");
                Console.WriteLine("7 - Ativar Bing no menu iniciar");
                Console.WriteLine("8 - Ativar Cortana");
                Console.WriteLine("9 - Ativar efeitos visuais");
                Console.WriteLine("10 - Ativar hibernação");
                Console.WriteLine("11 - Ativar histórico de atividade");
                Console.WriteLine("12 - Ativar indexação do Windows Search");
                Console.WriteLine("13 - Ativar indexação geral");
                Console.WriteLine("14 - Ativar notificações");
                Console.WriteLine("15 - Ativar ponto de restauração");
                Console.WriteLine("16 - Ativar serviço de relógio");
                Console.WriteLine("17 - Ativar serviços desnecessários");
                Console.WriteLine("18 - Ativar sugestões de pesquisa");
                Console.WriteLine("19 - Ativar tarefas agendadas");
                Console.WriteLine("20 - Ativar transição de janelas");
                Console.WriteLine("21 - Ativar transparência");
                Console.WriteLine("22 - Ativar Windows Aero");
                Console.WriteLine("23 - Ativar telemetria e coleta de dados");
                Console.WriteLine("24 - Restaurar bcdedit");
                Console.WriteLine("25 - Restaurar configurações do Explorer");
                Console.WriteLine("26 - Restaurar energia padrão");
                Console.WriteLine("27 - Restaurar velocidade ao abrir pastas");
                Console.WriteLine("28 - Ativar compactação NTFS");
                Console.WriteLine("29 - Ativar download de mapas");
                Console.WriteLine("30 - Ativar cache de miniaturas");
                Console.WriteLine("31 - Ativar limpeza automática de disco");
                Console.WriteLine("32 - Ativar recursos gráficos visuais");
                Console.WriteLine("33 - Ativar Windows Defender e notificações");
                Console.WriteLine("0 - Voltar");

                Console.Write("Escolha uma opção: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        _1_Ativ_Menos_Delay.Executar();
                        break;
                    case "2":
                        _2_Ativ_Win_Defender.Executar();
                        break;
                    case "3":
                        _3_Ativ_UAC.Executar();
                        break;
                    case "4":
                        _4_Ativ_Animaçao_Min_e_Max.Executar();
                        break;
                    case "5":
                        _5_Ativ_Animaçoes_Sistema.Executar();
                        break;
                    case "6":
                        _6_Ativ_Atualizaçoes_Auto.Executar();
                        break;
                    case "7":
                        _7_Ativ_Bing.Executar();
                        break;
                    case "8":
                        _8_Ativ_Cortana.Executar();
                        break;
                    case "9":
                        _9_Ativ_Efeitos_Visuais.Executar();
                        break;
                    case "10":
                        _10_Ativ_Hibernaçao.Executar();
                        break;
                    case "11":
                        _11_Ativ_Historico_Atividade.Executar();
                        break;
                    case "12":
                        _12_Ativ_Index_Windows_Search.Executar();
                        break;
                    case "13":
                        _13_Ativ_Indexação_Geral.Executar();
                        break;
                    case "14":
                        _14_Ativ_Notificaçoes.Executar();
                        break;
                    case "15":
                        _15_Ativ_Ponto_Restauraçao.Executar();
                        break;
                    case "16":
                        _16_Ativ_Serviço_Relogio.Executar();
                        break;
                    case "17":
                        _17_Ativ_Serviços.Executar();
                        break;
                    case "18":
                        _18_Ativ_Sugestoes_Pesquisa.Executar();
                        break;
                    case "19":
                        _19_Ativ_Tarefas_Agendadas.Executar();
                        break;
                    case "20":
                        _20_Ativ_Transiçao_Janelas.Executar();
                        break;
                    case "21":
                        _21_Ativ_Transparencia.Executar();
                        break;
                    case "22":
                        _22_Ativ_Windows_Aero.Executar();
                        break;
                    case "23":
                        _23_Ativ_Telemetria.Executar();
                        break;
                    case "24":
                        _24_Res_BcEdit.Executar();
                        break;
                    case "25":
                        _25_Res_Explorer.Executar();
                        break;
                    case "26":
                        _26_Res_Energia.Executar();
                        break;
                    case "27":
                        _27_Desat_Velocidade_Ao_Abrir_Pastas.Executar();
                        break;
                    case "28":
                        _28_Ativ_Compac_NTFS.Executar();
                        break;
                    case "29":
                        _29_Ativ_Download_Maps.Executar();
                        break;
                    case "30":
                        _30_Ativ_Armaz_Em_Cache_De_Miniatura.Executar();
                        break;
                    case "31":
                        _31_Ativ_Limpe_De_Disco_Auto.Executar();
                        break;
                    case "32":
                        _32_Ativ_Recurso_Grafico_Nao_Utilizados.Executar();
                        break;
                    case "33":
                        _33_Ativ_Win_Defender.Executar();
                        break;

                    case "0":
                        return;
                    
                    default:
                        Console.WriteLine("Opção inválida! Pressione qualquer tecla para tentar novamente.");
                        Console.ReadKey();
                        break;
                }

                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }
    }
}