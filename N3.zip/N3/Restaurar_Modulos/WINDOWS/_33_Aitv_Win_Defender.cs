﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _33_Ativ_Win_Defender
    {
        public static void Executar()
        {
            try
            {
                // Serviços: Start = 2 (automatico) é comum para muitos serviços do Defender
                string[] services = new string[]
                {
                    @"SYSTEM\CurrentControlSet\Services\wdboot",
                    @"SYSTEM\CurrentControlSet\Services\wdfilter",
                    @"SYSTEM\CurrentControlSet\Services\WinDefend",
                    @"SYSTEM\CurrentControlSet\Services\SecurityHealthService",
                    @"SYSTEM\CurrentControlSet\Services\wdnisdrv",
                    @"SYSTEM\CurrentControlSet\Services\mssecflt",
                    @"SYSTEM\CurrentControlSet\Services\WdNisSvc",
                    @"SYSTEM\CurrentControlSet\Services\Sense",
                    @"SYSTEM\CurrentControlSet\Services\wscsvc"
                };

                foreach (var svc in services)
                {
                    using (var key = Registry.LocalMachine.OpenSubKey(svc, writable: true))
                    {
                        if (key != null)
                        {
                            key.SetValue("Start", 2, RegistryValueKind.DWord); // Start automático (padrão comum)
                        }
                    }
                }

                // Policies Windows Defender (restaurar para 0)
                using (var keyDef = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows Defender", writable: true))
                {
                    if (keyDef != null)
                    {
                        keyDef.SetValue("DisableAntiSpyware", 0, RegistryValueKind.DWord);
                        keyDef.SetValue("DisableRoutinelyTakingAction", 0, RegistryValueKind.DWord);
                        keyDef.SetValue("ServiceKeepAlive", 1, RegistryValueKind.DWord);
                    }
                }

                using (var keyRealTime = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection", writable: true))
                {
                    if (keyRealTime != null)
                    {
                        keyRealTime.SetValue("DisableBehaviorMonitoring", 0, RegistryValueKind.DWord);
                        keyRealTime.SetValue("DisableIOAVProtection", 0, RegistryValueKind.DWord);
                        keyRealTime.SetValue("DisableOnAccessProtection", 0, RegistryValueKind.DWord);
                        keyRealTime.SetValue("DisableRealtimeMonitoring", 0, RegistryValueKind.DWord);
                    }
                }

                using (var keyReporting = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows Defender\Reporting", writable: true))
                {
                    if (keyReporting != null)
                    {
                        keyReporting.SetValue("DisableEnhancedNotifications", 0, RegistryValueKind.DWord);
                    }
                }

                using (var keyNotifications = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications", writable: true))
                {
                    if (keyNotifications != null)
                    {
                        keyNotifications.SetValue("DisableNotifications", 0, RegistryValueKind.DWord);
                    }
                }

                using (var keyPushNot = Registry.CurrentUser.OpenSubKey(@"Software\Policies\Microsoft\Windows\CurrentVersion\PushNotifications", writable: true))
                {
                    if (keyPushNot != null)
                    {
                        keyPushNot.SetValue("NoToastApplicationNotification", 0, RegistryValueKind.DWord);
                        keyPushNot.SetValue("NoToastApplicationNotificationOnLockScreen", 0, RegistryValueKind.DWord);
                    }
                }

                Console.WriteLine("Windows Defender restaurado ao padrão com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao restaurar Windows Defender: " + ex.Message);
            }
        }
    }
}
