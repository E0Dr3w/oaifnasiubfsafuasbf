﻿using Microsoft.Win32;
using System;


namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.PRIVACIDADE
{
    internal class _3_Ativ_Conta_E_Sync
        {
            public static void Executar()
            {
                try
                {
                    Console.WriteLine("[*] Restaurando login com conta Microsoft...");

                    // Permitir contas conectadas novamente (restaurar valores padrão)
                    Registry.SetValue(
                        @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
                        "NoConnectedUser", 0, RegistryValueKind.DWord
                    );

                    Registry.SetValue(
                        @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
                        "BlockConnectedAccount", 0, RegistryValueKind.DWord
                    );

                    Console.WriteLine("[*] Reativando sincronização com a nuvem...");

                    // Reativar sincronização de configurações (tema, senhas, etc.)
                    Registry.SetValue(
                        @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\SettingSync",
                        "DisableSettingSync", 0, RegistryValueKind.DWord
                    );

                    Console.WriteLine("[*] Conta Microsoft e sincronização restauradas.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[X] Erro ao restaurar políticas de conta Microsoft: {ex.Message}");
                }
            }
        }
    }
