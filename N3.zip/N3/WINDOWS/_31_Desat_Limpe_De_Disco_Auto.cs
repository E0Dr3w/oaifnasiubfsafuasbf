﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _31_Desat_Limpe_De_Disco_Auto
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer"))
                {
                    if (key != null)
                    {
                        key.SetValue("NoAutoClean", 1, RegistryValueKind.DWord);
                        Console.WriteLine("Limpeza automática de disco desativada.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao desativar limpeza automática de disco: " + ex.Message);
            }
        }
    }
}
