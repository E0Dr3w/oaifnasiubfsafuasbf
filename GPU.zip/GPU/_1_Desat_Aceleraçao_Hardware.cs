﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Modulos.GPU
{
    internal class _1_Desat_Aceleraçao_Hardware
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"System\GameConfigStore"))
                {
                    if (key != null)
                    {
                        key.SetValue("GameDVR_Enabled", 0, RegistryValueKind.DWord);
                        Console.WriteLine("GameDVR desativado com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Erro ao acessar a chave do Registro.");
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("Permissão negada. Execute como administrador.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }
    }
}