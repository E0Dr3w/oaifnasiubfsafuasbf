﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _17_Ativ_Serviços
    {
        public static void Executar()
        {
            string[] servicos = {
                "wisvc", "DPS", "TermService", "WbioSrvc", "TabletInputService",
                "wuauserv", "DiagTrack", "W32Time", "WaaSMedicSvc", "RetailDemo",
                "igts", "bthserv", "DoSvc", "Spooler", "RemoteRegistry",
                "SessionEnv", "PcaSvc", "Fax"
            };

            foreach (string nome in servicos)
            {
                try
                {
                    ExecutarComando($"sc config \"{nome}\" start= auto");
                    ExecutarComando($"sc start \"{nome}\"");
                    Console.WriteLine($"Serviço {nome} ativado com sucesso.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao ativar {nome}: {ex.Message}");
                }
            }
        }

        private static void ExecutarComando(string comando)
        {
            var proc = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = false,
                    RedirectStandardError = false
                }
            };
            proc.Start();
            proc.WaitForExit();
        }
    }
}
