﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.MEMORIA
{
    internal class _4_Ativ_Cache_De_Memoria_Para_Jogos
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management", true))
                {
                    if (key != null)
                    {
                        key.SetValue("IoPageLockLimit", 524288, RegistryValueKind.DWord);
                        Console.WriteLine("IoPageLockLimit ativado com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao ativar o IoPageLockLimit: " + ex.Message);
            }
        }
    }
}
