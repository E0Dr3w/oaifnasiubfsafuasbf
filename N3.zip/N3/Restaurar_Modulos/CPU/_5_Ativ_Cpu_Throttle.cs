﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.CPU
{
    internal class _5_Ativ_Cpu_Throttle
    {
        public static void Executar()
        {
            try
            {
                // Restaura o valor padrão de throttling da CPU (normalmente 100%)
                Process.Start("cmd.exe", "/c powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 100");
                Process.Start("cmd.exe", "/c powercfg -setactive SCHEME_CURRENT");

                Console.WriteLine("Throttle da CPU restaurado para o valor padrão (100%).");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao restaurar o throttle: {ex.Message}");
            }
        }
    }
}