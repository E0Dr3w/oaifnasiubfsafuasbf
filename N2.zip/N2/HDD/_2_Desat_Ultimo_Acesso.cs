﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aplicativos_de_modulos_para_Devs.Modulos.HDD
{
    internal class _2_Desat_Ultimo_Acesso
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando("fsutil behavior set disablelastaccess 2");
                Console.WriteLine("Atualização do último acesso desativada com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar atualização do último acesso: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                }
            };

            processo.Start();
            string output = processo.StandardOutput.ReadToEnd();
            string error = processo.StandardError.ReadToEnd();
            processo.WaitForExit();

            if (!string.IsNullOrEmpty(error))
                throw new Exception(error);
        }
    }
}