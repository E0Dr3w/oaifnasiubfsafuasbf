﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _32_Ativ_Recurso_Grafico_Nao_Utilizados
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("VisualFXSetting", "3", RegistryValueKind.String); // padrão Windows
                        Console.WriteLine("Configuração VisualFXSetting restaurada para 3 (padrão Windows).");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao restaurar VisualFXSetting: " + ex.Message);
            }
        }
    }
}
