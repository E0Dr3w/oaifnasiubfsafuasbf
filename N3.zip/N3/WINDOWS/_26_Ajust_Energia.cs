﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _26_Ajust_Energia
    {
        public static void Executar()
        {
            try
            {
                string[] caminhos = {
                    // GUID 1
                    @"SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e",
                    @"SYSTEM\CurrentControlSet\Control\Power\PowerSettings\2a737441-1930-4402-8d77-b2bebba308a3\d4e98f31-5ffe-4ce1-be31-1b38b384c009\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c",

                    // GUID 2
                    @"SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e",
                    @"SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\3b04d4fd-1cc7-4f23-ab1c-d1337819c4bb\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c",

                    // GUID 3
                    @"SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\4b92d758-5a24-4851-a470-815d78aee119\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e",
                    @"SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\4b92d758-5a24-4851-a470-815d78aee119\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c",

                    // GUID 4
                    @"SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\7b224883-b3cc-4d79-819f-8374152cbe7c\DefaultPowerSchemeValues\381b4222-f694-41f0-9685-ff5bb260df2e",
                    @"SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\7b224883-b3cc-4d79-819f-8374152cbe7c\DefaultPowerSchemeValues\8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"
                };

                foreach (string caminho in caminhos)
                {
                    using (RegistryKey key = Registry.LocalMachine.CreateSubKey(caminho))
                    {
                        if (key != null)
                        {
                            // Ajusta os valores conforme cada GUID
                            if (caminho.Contains("4b92d758") || caminho.Contains("7b224883"))
                            {
                                key.SetValue("ACSettingIndex", 100, RegistryValueKind.DWord);
                                key.SetValue("DCSettingIndex", 100, RegistryValueKind.DWord);
                            }
                            else if (caminho.EndsWith("8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"))
                            {
                                key.SetValue("ACSettingIndex", 0, RegistryValueKind.DWord);
                            }
                            else
                            {
                                key.SetValue("ACSettingIndex", 0, RegistryValueKind.DWord);
                                key.SetValue("DCSettingIndex", 0, RegistryValueKind.DWord);
                            }
                        }
                    }
                }

                Console.WriteLine("Ajustes de energia aplicados com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao aplicar os ajustes de energia: " + ex.Message);
            }
        }
    }
}
