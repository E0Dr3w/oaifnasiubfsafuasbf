﻿using System;
using Microsoft.Win32;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.PRIVACIDADE
{
    internal class _2_Desat_Serv_De_Localizaçao
    {
        public static void Executar()
        {
            try
            {
                Console.WriteLine("[*] Desativando serviço de localização...");

                // Parar e desativar o serviço lfsvc (Location Service)
                ExecutarComando("sc stop lfsvc");
                ExecutarComando("sc config lfsvc start= disabled");

                Console.WriteLine("[*] Desativando acesso à localização no registro...");

                // Impede que apps acessem a localização
                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location",
                    "Value", "Deny", RegistryValueKind.String
                );

                // Desativa o controle de localização do usuário atual
                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\lfsvc\TriggerInfo\3",
                    "Enabled", 0, RegistryValueKind.DWord
                );

                // (Extra) Desativa histórico de localização
                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\LocationAndSensors",
                    "DisableLocation", 1, RegistryValueKind.DWord
                );

                Console.WriteLine("[*] Localização desativada com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[X] Erro ao desativar localização: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c " + comando)
            {
                CreateNoWindow = true,
                UseShellExecute = false
            };
            Process.Start(psi)?.WaitForExit();
        }
    }
}