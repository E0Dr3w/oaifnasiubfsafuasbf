﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _22_Desat_Windows_Aero
    {
        public static void Executar()
        {
            try
            {
                Registry.SetValue(
                    @"HKEY_CURRENT_USER\Control Panel\Desktop",
                    "UserPreferencesMask",
                    new byte[] { 0x90, 0x12, 0x03, 0x80 },
                    RegistryValueKind.Binary
                );

                Console.WriteLine("Windows Aero desativado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar o Windows Aero: {ex.Message}");
            }
        }
    }
}
