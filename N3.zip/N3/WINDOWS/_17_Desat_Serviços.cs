﻿using System;
using System.Diagnostics;
using System.ServiceProcess;
using System.Threading;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _17_Desat_Serviços
    {
        public static void Executar()
        {
            string[] servicos = {
                // Serviços já presentes
                "wisvc", "DPS", "TermService", "WbioSrvc", "TabletInputService",
                "wuauserv", "DiagTrack", "W32Time", "WaaSMedicSvc", "RetailDemo",
                "igts", "bthserv", "DoSvc", "Spooler", "RemoteRegistry",
                "SessionEnv", "PcaSvc", "Fax", "AtherosSvc", "UsoSvc", "NcbService", "CDPSvc", "iphlpsvc", "lmhosts",
                "TrkWks", "ShellHWDetection", "LanmanWorkstation", "TokenBroker", "VaultSvc",
                "KeyIso", "LicenseManager", "RmSvc", "InstallService", "SysMain", "WSearch",
                "LanmanServer", "BDESVC", "DeviceAssociationService"
            };

            foreach (string nome in servicos)
            {
                try
                {
                    Console.WriteLine($"Tentando parar e desativar serviço: {nome}");

                    // 1. Para o serviço via API (mais confiável)
                    PararServico(nome, 10000); // timeout 10s

                    // 2. Força o stop com sc config start= disabled
                    ExecutarComando($"sc config \"{nome}\" start= disabled");

                    // 3. Mata processos remanescentes (force kill)
                    ForcarMatarProcessoDoServico(nome);

                    Console.WriteLine($"Serviço {nome} desativado com sucesso.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao desativar {nome}: {ex.Message}");
                }
            }

            // Modifica a chave do registro
            try
            {
                string regCommand = @"reg add ""HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control"" /v SvcHostSplitThresholdInKB /t REG_DWORD /d 4000000 /f";
                ExecutarComando(regCommand);
                Console.WriteLine("Registro SvcHostSplitThresholdInKB configurado com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao configurar registro: {ex.Message}");
            }
        }

        private static void PararServico(string nomeServico, int timeoutMs)
        {
            ServiceController sc = new ServiceController(nomeServico);

            if (sc.Status != ServiceControllerStatus.Stopped &&
                sc.Status != ServiceControllerStatus.StopPending)
            {
                // Tenta parar o serviço
                sc.Stop();

                // Aguarda o serviço parar
                sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromMilliseconds(timeoutMs));
            }
        }

        private static void ForcarMatarProcessoDoServico(string nomeServico)
        {
            // Tenta achar o processo pelo nome do serviço e mata
            try
            {
                // Consulta PID via comando sc queryex
                var psi = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c sc queryex \"{nomeServico}\"",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                var proc = Process.Start(psi);
                string output = proc.StandardOutput.ReadToEnd();
                proc.WaitForExit();

                // Extrai PID da saída (procura "PID : " na saída)
                int pid = -1;
                foreach (var line in output.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    if (line.Trim().StartsWith("PID"))
                    {
                        var parts = line.Split(':');
                        if (parts.Length == 2 && int.TryParse(parts[1].Trim(), out int p))
                        {
                            pid = p;
                            break;
                        }
                    }
                }

                if (pid > 0)
                {
                    try
                    {
                        Process procKill = Process.GetProcessById(pid);
                        procKill.Kill();
                        procKill.WaitForExit(5000);
                        Console.WriteLine($"Processo do serviço {nomeServico} com PID {pid} finalizado.");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Falha ao matar processo PID {pid} do serviço {nomeServico}: {ex.Message}");
                    }
                }
                else
                {
                    Console.WriteLine($"PID não encontrado para o serviço {nomeServico}.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao obter processo do serviço {nomeServico}: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var proc = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = false,
                    RedirectStandardError = false
                }
            };
            proc.Start();
            proc.WaitForExit();
        }
    }
}
