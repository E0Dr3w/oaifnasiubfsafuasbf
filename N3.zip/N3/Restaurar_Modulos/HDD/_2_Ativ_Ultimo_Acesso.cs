﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.HDD
{
    internal class _2_Ativ_Ultimo_Acesso
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando("fsutil behavior set disablelastaccess 0");
                Console.WriteLine("Atualização do último acesso ativada com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ativar atualização do último acesso: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                }
            };

            processo.Start();
            string output = processo.StandardOutput.ReadToEnd();
            string error = processo.StandardError.ReadToEnd();
            processo.WaitForExit();

            if (!string.IsNullOrEmpty(error))
                throw new Exception(error);
        }
    }
}