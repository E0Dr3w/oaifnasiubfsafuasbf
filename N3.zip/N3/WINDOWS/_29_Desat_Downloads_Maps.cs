﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _29_Desat_Downloads_Maps
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services\MapsBroker", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("Start", 4, RegistryValueKind.DWord); // 4 = desativado
                        Console.WriteLine("Serviço MapsBroker desativado.");
                    }
                    else
                    {
                        Console.WriteLine("Chave MapsBroker não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao desativar MapsBroker: " + ex.Message);
            }
        }
    }
}
