﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _24_Res_BcEdit
    {
        public static void Executar()
        {
            string[] comandos = new string[]
            {
                "bcdedit /deletevalue useplatformtick",
                "bcdedit /deletevalue disabledynamictick",
                "bcdedit /deletevalue nx",
                "bcdedit /deletevalue bootux",
                "bcdedit /set bootmenupolicy standard",
                "bcdedit /set hypervisorlaunchtype auto",
                "bcdedit /deletevalue tpmbootentropy",
                "bcdedit /deletevalue quietboot",
                "bcdedit /deletevalue linearaddress57",
                "bcdedit /deletevalue increaseuserva",
                "bcdedit /deletevalue firstmegabytepolicy",
                "bcdedit /deletevalue avoidlowmemory",
                "bcdedit /deletevalue nolowmem",
                "bcdedit /deletevalue allowedinmemorysettings",
                "bcdedit /deletevalue isolatedcontext"
            };

            foreach (var cmd in comandos)
            {
                ExecutarComando(cmd);
            }

            Console.WriteLine("Parâmetros BCDEDIT restaurados para o padrão.");
        }

        private static void ExecutarComando(string comando)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = "/c " + comando,
                Verb = "runas",
                CreateNoWindow = true,
                UseShellExecute = true
            })?.WaitForExit();
        }
    }
}
