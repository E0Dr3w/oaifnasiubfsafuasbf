﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _24_Otim_BcEdit
    {
        public static void Executar()
        {
            string[] comandos = new string[]
            {
                "bcdedit /set useplatformtick yes",
                "bcdedit /set disabledynamictick yes",
                "bcdedit /set nx optout",
                "bcdedit /set bootux disabled",
                "bcdedit /set bootmenupolicy standard",
                "bcdedit /set hypervisorlaunchtype off",
                "bcdedit /set tpmbootentropy ForceDisable",
                "bcdedit /set quietboot yes",
                "bcdedit /set linearaddress57 OptOut",
                "bcdedit /set increaseuserva 268435328",
                "bcdedit /set firstmegabytepolicy UseAll",
                "bcdedit /set avoidlowmemory 0x8000000",
                "bcdedit /set nolowmem Yes",
                "bcdedit /set allowedinmemorysettings 0x0",
                "bcdedit /set isolatedcontext No"
            };

            foreach (var cmd in comandos)
            {
                ExecutarComando(cmd);
            }

            Console.WriteLine("Otimizações BCDEDIT aplicadas com sucesso.");
        }

        private static void ExecutarComando(string comando)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = "/c " + comando,
                Verb = "runas", // executa como administrador
                CreateNoWindow = true,
                UseShellExecute = true
            })?.WaitForExit();
        }
    }
}
