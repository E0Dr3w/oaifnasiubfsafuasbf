﻿using System;
using Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.GPU;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos
{
    internal class Res_GPU
    {
        public static void Executar()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Restauração GPU ===");
                Console.WriteLine("1 - Ativar Aceleração de Hardware");
                Console.WriteLine("2 - Ativar Reduçao de Taxa de atualizaçao");
                Console.WriteLine("3 - Desativar Prioridade Directx");
                Console.WriteLine("0 - Voltar");
                Console.Write("Escolha uma opção: ");

                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        _1_Ativ_Aceleraçao_Hardware.Executar();
                        break;
                    case "2":
                        _2_Ativ_Reduçao_Taxa_De_Atualizaçoes.Executar();
                        break;
                    case "3":
                        _3_Desat_Prioridade_DirectX.Executar();
                        break;
                    case "0":
                        return;
                    default:
                        Console.WriteLine("Opção inválida! Pressione qualquer tecla para tentar novamente.");
                        Console.ReadKey();
                        break;
                }

                Console.WriteLine("\nPressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }
    }
}