﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _5_Ativ_Animaçoes_Sistema
    {
        public static void Executar()
        {
            try
            {
                byte[] valor = new byte[] { 0x90, 0x12, 0x03, 0x00 };
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"Control Panel\Desktop"))
                {
                    key.SetValue("UserPreferencesMask", valor, RegistryValueKind.Binary);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }
    }
}
