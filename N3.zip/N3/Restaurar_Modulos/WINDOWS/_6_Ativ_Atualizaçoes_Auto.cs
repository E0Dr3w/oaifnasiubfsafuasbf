﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _6_Ativ_Atualizaçoes_Auto
    {
        public static void Executar()
        {
            try
            {
                // Habilitar serviços
                ExecutarComando("sc config wuauserv start= auto");
                ExecutarComando("net start wuauserv");

                ExecutarComando("sc config bits start= delayed-auto");
                ExecutarComando("net start bits");

                ExecutarComando("sc config dosvc start= manual");
                ExecutarComando("net start dosvc");

                // Remover chave de registro que desativa atualizações automáticas
                ExecutarComando(@"reg delete ""HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"" /v NoAutoUpdate /f");

                Console.WriteLine("Atualizações automáticas ativadas com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ativar atualizações automáticas: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            Process processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
