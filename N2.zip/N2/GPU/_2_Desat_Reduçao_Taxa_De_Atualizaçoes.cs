﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.GPU
{
    internal class _2_Desat_Reduçao_Taxa_De_Atualizaçoes
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\DWM"))
                {
                    if (key != null)
                    {
                        key.SetValue("EnableUserDWM", 0, RegistryValueKind.DWord);
                        Console.WriteLine("Redução de taxa de atualizações desativada com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao desativar a redução de taxa de atualizações: " + ex.Message);
            }
        }
    }
}
