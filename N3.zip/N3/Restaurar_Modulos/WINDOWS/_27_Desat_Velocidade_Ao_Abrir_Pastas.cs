﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _27_Desat_Velocidade_Ao_Abrir_Pastas
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\FileSystem", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("NtfsDisableLastAccessUpdate", 0, RegistryValueKind.DWord);
                        Console.WriteLine("Configuração de abertura de pastas restaurada ao padrão.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao restaurar configuração de abertura de pastas: " + ex.Message);
            }
        }
    }
}
