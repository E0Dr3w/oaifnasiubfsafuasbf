﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _33_Desat_Win_Defender
    {
        public static void Executar()
        {
            try
            {
                // Serviços: Start = 4 (desativado)
                string[] services = new string[]
                {
                    @"SYSTEM\CurrentControlSet\Services\wdboot",
                    @"SYSTEM\CurrentControlSet\Services\wdfilter",
                    @"SYSTEM\CurrentControlSet\Services\WinDefend",
                    @"SYSTEM\CurrentControlSet\Services\SecurityHealthService",
                    @"SYSTEM\CurrentControlSet\Services\wdnisdrv",
                    @"SYSTEM\CurrentControlSet\Services\mssecflt",
                    @"SYSTEM\CurrentControlSet\Services\WdNisSvc",
                    @"SYSTEM\CurrentControlSet\Services\Sense",
                    @"SYSTEM\CurrentControlSet\Services\wscsvc"
                };

                foreach (var svc in services)
                {
                    using (var key = Registry.LocalMachine.OpenSubKey(svc, writable: true))
                    {
                        if (key != null)
                        {
                            key.SetValue("Start", 4, RegistryValueKind.DWord);
                        }
                    }
                }

                // Policies Windows Defender (DWORD)
                using (var keyDef = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Policies\Microsoft\Windows Defender"))
                {
                    keyDef.SetValue("DisableAntiSpyware", 1, RegistryValueKind.DWord);
                    keyDef.SetValue("DisableRoutinelyTakingAction", 1, RegistryValueKind.DWord);
                    keyDef.SetValue("ServiceKeepAlive", 0, RegistryValueKind.DWord);
                }

                using (var keyRealTime = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection"))
                {
                    keyRealTime.SetValue("DisableBehaviorMonitoring", 1, RegistryValueKind.DWord);
                    keyRealTime.SetValue("DisableIOAVProtection", 1, RegistryValueKind.DWord);
                    keyRealTime.SetValue("DisableOnAccessProtection", 1, RegistryValueKind.DWord);
                    keyRealTime.SetValue("DisableRealtimeMonitoring", 1, RegistryValueKind.DWord);
                }

                using (var keyReporting = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Policies\Microsoft\Windows Defender\Reporting"))
                {
                    keyReporting.SetValue("DisableEnhancedNotifications", 1, RegistryValueKind.DWord);
                }

                using (var keyNotifications = Registry.LocalMachine.CreateSubKey(@"SOFTWARE\Policies\Microsoft\Windows Defender Security Center\Notifications"))
                {
                    keyNotifications.SetValue("DisableNotifications", 1, RegistryValueKind.DWord);
                }

                using (var keyPushNot = Registry.CurrentUser.CreateSubKey(@"Software\Policies\Microsoft\Windows\CurrentVersion\PushNotifications"))
                {
                    keyPushNot.SetValue("NoToastApplicationNotification", 1, RegistryValueKind.DWord);
                    keyPushNot.SetValue("NoToastApplicationNotificationOnLockScreen", 1, RegistryValueKind.DWord);
                }

                Console.WriteLine("Windows Defender desativado com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao desativar Windows Defender: " + ex.Message);
            }
        }
    }
}
