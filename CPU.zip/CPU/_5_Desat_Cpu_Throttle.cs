﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.CPU
{
    internal class _5_Desat_Cpu_Throttle
    {
        public static void Executar()
        {
            try
            {
                // Define o valor máximo do throttle para 100% no plano ativo (modo com carregador)
                Process.Start("cmd.exe", "/c powercfg -setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 100");
                Process.Start("cmd.exe", "/c powercfg -setactive SCHEME_CURRENT");

                Console.WriteLine("Throttle da CPU desativado com sucesso (100%).");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao aplicar a configuração: {ex.Message}");
            }
        }
    }
}