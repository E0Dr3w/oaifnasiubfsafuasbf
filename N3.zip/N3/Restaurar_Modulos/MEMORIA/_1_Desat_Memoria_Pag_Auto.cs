﻿using System;
using System.Management;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.MEMORIA
{
    internal class _1_Desat_Memoria_Pag_Auto
    {
        public static void Executar()
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher(
                    $"SELECT * FROM Win32_ComputerSystem WHERE Name = '{Environment.MachineName}'"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        obj["AutomaticManagedPagefile"] = true; // Restaura para automático
                        obj.Put();

                        Console.WriteLine("Arquivo de paginação restaurado para gerenciamento automático.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao restaurar arquivo de paginação: {ex.Message}");
            }
        }
    }
}
