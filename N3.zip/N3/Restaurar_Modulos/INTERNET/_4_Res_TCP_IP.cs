﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.INTERNET
{
    internal class _4_Res_TCP_IP
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando("netsh int tcp set global autotuninglevel=normal");
                ExecutarComando("netsh int tcp set global chimney=default");
                ExecutarComando("netsh int tcp set global congestionprovider=none");
                ExecutarComando("netsh int tcp set global ecncapability=disabled");
                ExecutarComando("netsh int tcp set global timestamps=enabled");
                ExecutarComando("netsh int tcp set global rss=enabled");
                ExecutarComando("netsh int tcp set global rsc=disabled");

                Console.WriteLine("Parâmetros TCP/IP restaurados para o padrão do Windows.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao restaurar TCP/IP: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };

            processo.Start();
            processo.StandardOutput.ReadToEnd();
            string error = processo.StandardError.ReadToEnd();
            processo.WaitForExit();

            if (!string.IsNullOrEmpty(error) && !error.Contains("OK."))
                throw new Exception(error);
        }
    }
}
