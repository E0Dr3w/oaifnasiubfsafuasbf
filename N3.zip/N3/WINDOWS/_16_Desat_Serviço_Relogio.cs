﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _16_Desat_Serviço_Relogio
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando("sc stop W32Time");
                ExecutarComando("sc config W32Time start= disabled");
                Console.WriteLine("Serviço de relógio desativado e parado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar serviço de relógio: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
