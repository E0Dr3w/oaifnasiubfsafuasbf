﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.CPU
{
    internal class _2_Ativ_Intel_PPM
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Services\intelppm"))
                {
                    if (key != null)
                    {
                        key.SetValue("Start", 3, RegistryValueKind.DWord);
                        Console.WriteLine("Registro atualizado com sucesso: intelppm Start = 3");
                    }
                    else
                    {
                        Console.WriteLine("Erro ao acessar a chave do Registro.");
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("Permissão negada. Execute como administrador.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }
    }
}