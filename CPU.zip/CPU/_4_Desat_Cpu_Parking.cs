﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Modulos.CPU
{
    internal class _4_Desat_Cpu_Parking
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.CreateSubKey(
                    @"SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4637-891a-dec35c318583"))
                {
                    if (key != null)
                    {
                        key.SetValue("ValueMin", 0, RegistryValueKind.DWord);
                        key.SetValue("ValueMax", 0, RegistryValueKind.DWord);
                        Console.WriteLine("CPU Parking desativado com sucesso (ValueMin e ValueMax = 0).");
                    }
                    else
                    {
                        Console.WriteLine("Erro ao acessar a chave do Registro.");
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine("Permissão negada. Execute como administrador.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }
    }
}