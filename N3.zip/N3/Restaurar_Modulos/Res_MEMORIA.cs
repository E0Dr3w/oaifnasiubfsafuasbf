﻿using Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.MEMORIA;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos
{
    internal class Res_MEMORIA
    {
        public static void Executar()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== Restauração MEMORIA ===");
                Console.WriteLine("1 - Desativar Memoria Paginavel automatica");
                Console.WriteLine("2 - Ativar Cache Grande");
                Console.WriteLine("3 - Desativar Indexação do Windows");
                Console.WriteLine("4 - Desativar Cache de Memoria para jogos");
                Console.WriteLine("5 - Restaurar Uso de Ram");
                Console.WriteLine("0 - Voltar");

                Console.Write("Escolha uma opção: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        _1_Desat_Memoria_Pag_Auto.Executar();
                        break;

                    case "2":
                        _2_Ativ_Cache_Grande.Executar();
                        break;

                    case "3":
                        _3_Desat_Gerenciamento_Auto_De_Memoria_Pag.Executar();
                        break;

                    case "4":
                        _4_Desat_Cache_De_Memoria_Para_Jogos.Executar();
                        break;

                    case "5":
                        _5_Restaurar_Uso_De_Ram.Executar();
                        break;

                    case "0":
                        return;

                    default:
                        Console.WriteLine("Opção inválida! Pressione qualquer tecla para tentar novamente.");
                        break;
                }

                Console.WriteLine("Pressione qualquer tecla para continuar...");
                Console.ReadKey();
            }
        }
    }
}
