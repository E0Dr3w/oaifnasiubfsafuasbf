﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.INTERNET
{
    internal class _1_Ajustes_No_AFD
    {
        public static void Executar()
        {
            try
            {
                // Caminhos das chaves do registro
                string[] keys = new string[]
                {
                    @"SYSTEM\CurrentControlSet\Services\AFD\Parameters",
                    @"System\ControlSet001\Services\AFD\Parameters",
                    @"System\CurrentControlSet\Services\ADF\Parameters",
                    @"System\CurrentControlSet\services\AeLookupSvc"
                };

                // Exemplo de valores para SYSTEM\CurrentControlSet\Services\AFD\Parameters
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "DefaultSendWindow", 16384, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "FastCopyReceiveThreshold", 16384, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "FastSendDatagramThreshold", 16384, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "DynamicSendBufferDisable", 0, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "DefaultReceiveWindow", 16384, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "IgnorePushBitOnReceives", 1, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "NonBlockingSendSpecialBuffering", 1, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "DisableRawSecurity", 1, RegistryValueKind.DWord);

                // Alguns valores duplicados no script original são evitados aqui
                // Valores para System\ControlSet001\Services\AFD\Parameters
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "DefaultReceiveWindow", 8192, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "DefaultSendWindow", 4096, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "DisableAddressSharing", 1, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "FastSendDatagramThreshold", 1024, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "IgnorePushBitOnReceives", 0, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "InitialLargeBufferCount", 20, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "InitialMediumBufferCount", 48, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "InitialSmallBufferCount", 64, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "LargeBufferSize", 40960, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "MaxFastTransmit", 6400, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "MediumBufferSize", 15040, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "PriorityBoost", 0, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "SmallBufferSize", 1280, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\ControlSet001\Services\AFD\Parameters", "TransmitWorker", 32, RegistryValueKind.DWord);

                // Exemplo valores para System\CurrentControlSet\Services\ADF\Parameters
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "DisablePagingExecutive", 1, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "DisableStrictNameChecking", 1, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "DynamicBacklogGrowthDelta", 256, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "EnableDynamicBacklog", 1, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "IRPStackSize", 32, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "MaximumDynamicBacklog", 131072, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "MaxMpxCt", 2048, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "MaxWorkItems", 8192, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "MinimumDynamicBacklog", 512, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "Size", 3, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "SizReqBuf", 17424, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\Services\ADF\Parameters", "SystemPages", UInt32.MaxValue, RegistryValueKind.DWord);

                // Exemplo valores para AeLookupSvc
                SetRegistryValue(Registry.LocalMachine, @"System\CurrentControlSet\services\AeLookupSvc", "Start", 4, RegistryValueKind.DWord);

                // Exemplo adicionais para AFD parâmetros (valores variados)
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "GlobalMaxTcpWindowSize", 3539039, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "KeepAliveInterval", 1, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "TcpMaxDupAcks", 3, RegistryValueKind.DWord);
                SetRegistryValue(Registry.LocalMachine, @"SYSTEM\CurrentControlSet\Services\AFD\Parameters", "TcpTimedWaitDelay", 30, RegistryValueKind.DWord);

                Console.WriteLine("Ajustes aplicados com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao aplicar ajustes: " + ex.Message);
            }
        }

        private static void SetRegistryValue(RegistryKey root, string subKey, string valueName, object value, RegistryValueKind valueKind)
        {
            using (RegistryKey key = root.OpenSubKey(subKey, writable: true) ?? root.CreateSubKey(subKey))
            {
                if (key == null)
                {
                    throw new Exception($"Não foi possível abrir ou criar a chave: {subKey}");
                }
                key.SetValue(valueName, value, valueKind);
            }
        }
    }
}
