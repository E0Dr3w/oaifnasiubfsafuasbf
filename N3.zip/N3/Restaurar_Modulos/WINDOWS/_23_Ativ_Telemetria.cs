﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _23_Ativ_Telemetria
    {
        public static void Executar()
        {
            try
            {
                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DataCollection",
                    "AllowTelemetry",
                    1,
                    RegistryValueKind.DWord
                );

                Console.WriteLine("Telemetria ativada (nível básico).");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ativar a telemetria: {ex.Message}");
            }
        }
    }
}
