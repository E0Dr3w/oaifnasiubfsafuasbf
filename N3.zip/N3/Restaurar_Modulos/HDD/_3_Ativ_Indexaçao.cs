﻿using System;
using System.Management;
using System.ServiceProcess;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.HDD
{
    internal class _3_Ativ_Indexaçao
    {
        public static void Executar()
        {
            try
            {
                string serviceName = "WSearch";

                // Alterar para start = automatic
                using (ManagementObject service = new ManagementObject($"Win32_Service.Name='{serviceName}'"))
                {
                    var inParams = service.GetMethodParameters("ChangeStartMode");
                    inParams["StartMode"] = "Automatic";
                    var outParams = service.InvokeMethod("ChangeStartMode", inParams, null);
                    uint ret = (uint)outParams.Properties["ReturnValue"].Value;

                    if (ret == 0)
                    {
                        Console.WriteLine("Serviço habilitado para iniciar automaticamente.");
                    }
                    else
                    {
                        Console.WriteLine($"Falha ao habilitar o serviço. Código: {ret}");
                        return;
                    }
                }

                // Iniciar o serviço se não estiver rodando
                using (ServiceController sc = new ServiceController(serviceName))
                {
                    if (sc.Status == ServiceControllerStatus.Stopped ||
                        sc.Status == ServiceControllerStatus.StopPending)
                    {
                        Console.WriteLine("Iniciando serviço de indexação...");
                        sc.Start();
                        sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(10));
                        Console.WriteLine("Serviço iniciado.");
                    }
                    else
                    {
                        Console.WriteLine("Serviço já está em execução.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }
    }
}