﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _21_Desat_Transparencia
    {
        public static void Executar()
        {
            try
            {
                Registry.SetValue(
                    @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize",
                    "EnableTransparency",
                    0,
                    RegistryValueKind.DWord
                );

                Console.WriteLine("Transparência desativada.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar transparência: {ex.Message}");
            }
        }
    }
}
