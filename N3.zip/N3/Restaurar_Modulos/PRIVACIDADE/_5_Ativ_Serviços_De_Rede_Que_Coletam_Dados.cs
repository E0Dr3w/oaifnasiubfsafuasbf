﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.PRIVACIDADE
{
    internal class _5_Ativ_Serviços_De_Rede_Que_Coletam_Dados
    {
        public static void Executar()
        {
            try
            {
                Console.WriteLine("[*] Restaurando serviços de rede...");

                string[] servicos = {
                    "WdiServiceHost",
                    "WdiSystemHost",
                    "WinRM",
                    "RemoteRegistry",
                    "NetTcpPortSharing",
                    "RemoteAccess",
                    "SharedAccess",
                    "DoSvc"
                };

                foreach (var servico in servicos)
                {
                    ExecutarComando($"sc config {servico} start= demand");
                    ExecutarComando($"sc start {servico}");
                }

                Console.WriteLine("[*] Serviços de rede restaurados com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[X] Erro ao restaurar serviços de rede: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c " + comando)
            {
                CreateNoWindow = true,
                UseShellExecute = false
            };
            Process.Start(psi)?.WaitForExit();
        }
    }
}