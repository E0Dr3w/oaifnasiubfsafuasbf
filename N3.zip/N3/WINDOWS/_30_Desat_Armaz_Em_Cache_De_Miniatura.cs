﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _30_Desat_Armaz_Em_Cache_De_Miniatura
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("DisableThumbnailCache", 1, RegistryValueKind.DWord);
                        Console.WriteLine("Armazenamento em cache de miniaturas desativado.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao desativar cache de miniaturas: " + ex.Message);
            }
        }
    }
}
