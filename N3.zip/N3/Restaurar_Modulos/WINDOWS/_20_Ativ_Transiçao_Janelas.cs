﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _20_Ativ_Transiçao_Janelas
    {
        public static void Executar()
        {
            try
            {
                Registry.SetValue(
                    @"HKEY_CURRENT_USER\Control Panel\Desktop",
                    "UserPreferencesMask",
                    new byte[] { 0x9E, 0x3E, 0x07, 0x80 },
                    RegistryValueKind.Binary
                );

                Console.WriteLine("Transições de janelas ativadas.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ativar transições de janelas: {ex.Message}");
            }
        }
    }
}
