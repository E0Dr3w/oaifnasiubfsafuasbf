﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.GPU
{
    internal class _3_Ativ_Prioridade_DirectX
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Control\FileSystem"))
                {
                    if (key != null)
                    {
                        key.SetValue("NtfsDisableLastAccessUpdate", 1, RegistryValueKind.DWord);
                        Console.WriteLine("Atualização de último acesso desativada (otimização para DirectX aplicada).");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao aplicar prioridade DirectX: " + ex.Message);
            }
        }
    }
}
