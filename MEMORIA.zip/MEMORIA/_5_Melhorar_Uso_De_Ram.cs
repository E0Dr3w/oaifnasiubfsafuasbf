﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Modulos.MEMORIA
{
    internal class _5_Melhorar_Uso_De_Ram
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"))
                {
                    if (key != null)
                    {
                        key.SetValue("ClearPageFileAtShutdown", 1, RegistryValueKind.DWord);
                        key.SetValue("LargeSystemCache", 0, RegistryValueKind.DWord);
                        key.SetValue("DisablePagingExecutive", 1, RegistryValueKind.DWord);
                        key.SetValue("SecondLevelDataCache", 0x100, RegistryValueKind.DWord); // 256 decimal

                        Console.WriteLine("Otimizações de memória aplicadas com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao aplicar otimizações de memória: " + ex.Message);
            }
        }
    }
}
