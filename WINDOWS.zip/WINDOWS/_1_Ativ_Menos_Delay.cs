﻿using Microsoft.Win32;
using System;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _1_Ativ_Menos_Delay
    {
        public static void Executar()
        {
            // Atualiza MenuShowDelay para usuário atual
            try
            {
                using (RegistryKey keyUser = Registry.CurrentUser.OpenSubKey(@"Control Panel\Desktop", writable: true))
                {
                    if (keyUser != null)
                    {
                        keyUser.SetValue("MenuShowDelay", "0", RegistryValueKind.String);
                        // Adiciona os novos valores WaitToKillAppTimeout e HungAppTimeout
                        keyUser.SetValue("WaitToKillAppTimeout", "0", RegistryValueKind.String);
                        keyUser.SetValue("HungAppTimeout", "0", RegistryValueKind.String);

                        Console.WriteLine("Configurações do desktop atualizadas com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Erro ao acessar HKCU\\Control Panel\\Desktop");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao modificar configurações do desktop: {ex.Message}");
            }

            // Atualiza valores no HKLM\SYSTEM\CurrentControlSet\Control
            try
            {
                using (RegistryKey keyMachine = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Control", writable: true))
                {
                    if (keyMachine != null)
                    {
                        // WaitToKillServiceTimeout é string
                        keyMachine.SetValue("WaitToKillServiceTimeout", "0", RegistryValueKind.String);

                        // LastBootSucceeded é DWORD
                        keyMachine.SetValue("LastBootSucceeded", 1, RegistryValueKind.DWord);

                        // LastBootShutdown é DWORD
                        keyMachine.SetValue("LastBootShutdown", 1, RegistryValueKind.DWord);

                        Console.WriteLine("Chaves do registro HKLM\\SYSTEM\\CurrentControlSet\\Control atualizadas com sucesso.");
                    }
                    else
                    {
                        Console.WriteLine("Erro ao acessar HKLM\\SYSTEM\\CurrentControlSet\\Control");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao modificar chaves HKLM: {ex.Message}");
            }
        }
    }
}
