﻿using Microsoft.Win32;
using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.PRIVACIDADE
{
    internal class _1_Desat_Telemetria
    {
        public static void Executar()
        {
            try
            {
                Console.WriteLine("[*] Desativando serviços de telemetria...");

                // Parar e desativar serviços
                string[] servicos = { "DiagTrack", "dmwappushsvc" };
                foreach (string servico in servicos)
                {
                    ExecutarComando($"sc stop {servico}");
                    ExecutarComando($"sc config {servico} start= disabled");
                }

                Console.WriteLine("[*] Editando registro para reduzir nível de diagnóstico...");

                // Definir Telemetria como Security (0) – Funciona apenas em algumas versões
                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DataCollection",
                    "AllowTelemetry", 0, RegistryValueKind.DWord
                );

                Registry.SetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection",
                    "AllowTelemetry", 0, RegistryValueKind.DWord
                );

                Console.WriteLine("[*] Desativando tarefas agendadas de telemetria...");

                string[] tarefas = {
                    @"Microsoft\Windows\Application Experience\ProgramDataUpdater",
                    @"Microsoft\Windows\Autochk\Proxy",
                    @"Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
                    @"Microsoft\Windows\Customer Experience Improvement Program\UsbCeip",
                    @"Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"
                };

                foreach (string tarefa in tarefas)
                {
                    ExecutarComando($"schtasks /Change /TN \"{tarefa}\" /Disable");
                }

                Console.WriteLine("[*] Finalizado com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[X] Erro ao desativar telemetria: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c " + comando)
            {
                CreateNoWindow = true,
                UseShellExecute = false
            };
            Process.Start(psi)?.WaitForExit();
        }
    }
}
