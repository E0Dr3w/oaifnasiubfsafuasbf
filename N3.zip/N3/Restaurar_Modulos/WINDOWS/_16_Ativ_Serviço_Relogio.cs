﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _16_Ativ_Serviço_Relogio
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando("sc config W32Time start= auto");
                ExecutarComando("sc start W32Time");
                Console.WriteLine("Serviço de relógio ativado e iniciado.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao ativar serviço de relógio: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
