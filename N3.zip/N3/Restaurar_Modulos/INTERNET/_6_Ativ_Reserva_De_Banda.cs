﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.INTERNET
{
    internal class _6_Ativ_Reserva_De_Banda
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando(@"REG ADD ""HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\Psched"" /v NonBestEffortLimit /t REG_DWORD /d 20 /f");
                Console.WriteLine("Reserva de banda restaurada para padrão (NonBestEffortLimit = 20).");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao restaurar reserva de banda: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                }
            };

            processo.Start();
            string output = processo.StandardOutput.ReadToEnd();
            string error = processo.StandardError.ReadToEnd();
            processo.WaitForExit();

            if (!string.IsNullOrEmpty(error) && !error.Contains("OK."))
                throw new Exception(error);
        }
    }
}
