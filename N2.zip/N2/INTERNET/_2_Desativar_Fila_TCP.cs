﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.INTERNET
{
    internal class _2_Desativar_Fila_TCP
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando("netsh int tcp set global qmgrlimit=0");
                Console.WriteLine("Fila TCP (qmgrlimit) desativada com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar fila TCP: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "cmd.exe",
                    Arguments = $"/c {comando}",
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true
                }
            };

            processo.Start();
            string output = processo.StandardOutput.ReadToEnd();
            string error = processo.StandardError.ReadToEnd();
            processo.WaitForExit();

            if (!string.IsNullOrEmpty(error) && !error.Contains("OK."))
                throw new Exception(error);
        }
    }
}
