﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.APPS
{
    internal class _10_Microsoft_Windows_CallingShellApp
    {
        public static void Executar()
        {
            string[] callingShellAppPackages =
            {
                "Microsoft.Windows.CallingShellApp"
            };

            foreach (var package in callingShellAppPackages)
            {
                try
                {
                    Console.WriteLine($"\n[•] Iniciando remoção de: {package}");

                    var psi = new ProcessStartInfo
                    {
                        FileName = "powershell.exe",
                        Arguments = $"-Command \"Get-AppxPackage *{package}* | Remove-AppxPackage; " +
                                    $"Get-AppxProvisionedPackage -Online | Where-Object {{$_.PackageName -like '*{package}*'}} | Remove-AppxProvisionedPackage -Online\"",
                        UseShellExecute = false,
                        RedirectStandardOutput = true,
                        RedirectStandardError = true,
                        CreateNoWindow = true,
                        Verb = "runas"
                    };

                    using (var process = Process.Start(psi))
                    {
                        string output = process.StandardOutput.ReadToEnd();
                        string error = process.StandardError.ReadToEnd();
                        process.WaitForExit();

                        if (!string.IsNullOrWhiteSpace(output))
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine($"[✓] {package} removido com sucesso.");
                            Console.WriteLine($"[Detalhes]:\n{output}");
                            Console.ResetColor();
                        }

                        if (!string.IsNullOrWhiteSpace(error))
                        {
                            if (error.Contains("Remove-AppxProvisionedPackage") && error.Contains("não pode encontrar o caminho especificado"))
                            {
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine($"[!] {package}: pacote provisionado não encontrado (provavelmente já removido).");
                                Console.ResetColor();
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine($"[X] Erro ao remover {package}.");
                                Console.WriteLine($"[Erro detalhado]:\n{error}");
                                Console.ResetColor();
                            }
                        }

                        if (string.IsNullOrWhiteSpace(output) && string.IsNullOrWhiteSpace(error))
                        {
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine($"[!] Nenhuma resposta recebida ao tentar remover {package}. Verifique permissões.");
                            Console.ResetColor();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"[X] Exceção crítica ao tentar remover {package}:\n{ex.Message}");
                    Console.ResetColor();
                }
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n[✓] Processo de remoção do pacote Microsoft.Windows.CallingShellApp finalizado.");
            Console.ResetColor();
        }
    }
}