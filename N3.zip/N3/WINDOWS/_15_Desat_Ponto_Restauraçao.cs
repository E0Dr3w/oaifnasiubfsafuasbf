﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _15_Desat_Ponto_Restauraçao
    {
        public static void Executar()
        {
            try
            {
                // Limitar armazenamento para 1GB
                ExecutarComando("vssadmin resize shadowstorage /for=C: /on=C: /maxsize=1GB");

                // Parar serviço Volume Shadow Copy
                ExecutarComando("sc stop vss");

                // Desabilitar serviço Volume Shadow Copy
                ExecutarComando("sc config vss start= disabled");

                // Desativar proteção do sistema via registro
                ExecutarComando(@"reg add ""HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore"" /v DisableSR /t REG_DWORD /d 1 /f");

                Console.WriteLine("Ponto de restauração desativado e armazenamento limitado com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar ponto de restauração: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
