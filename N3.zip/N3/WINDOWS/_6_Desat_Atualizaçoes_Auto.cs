﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _6_Desat_Atualizaçoes_Auto
    {
        public static void Executar()
        {
            try
            {
                // Parar e desabilitar serviços
                ExecutarComando("net stop wuauserv");
                ExecutarComando("sc config wuauserv start= disabled");

                ExecutarComando("net stop bits");
                ExecutarComando("sc config bits start= disabled");

                ExecutarComando("net stop dosvc");
                ExecutarComando("sc config dosvc start= disabled");

                // Definir chave de registro para desativar atualizações automáticas
                ExecutarComando(@"reg add ""HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"" /v NoAutoUpdate /t REG_DWORD /d 1 /f");

                Console.WriteLine("Atualizações automáticas desativadas com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar atualizações automáticas: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            Process processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}