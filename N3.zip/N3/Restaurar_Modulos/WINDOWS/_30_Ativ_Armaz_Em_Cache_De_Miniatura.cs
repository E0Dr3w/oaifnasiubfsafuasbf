﻿using System;
using Microsoft.Win32;

namespace Aplicativos_de_modulos_para_Devs.Restaurar_Modulos.WINDOWS
{
    internal class _30_Ativ_Armaz_Em_Cache_De_Miniatura
    {
        public static void Executar()
        {
            try
            {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced", writable: true))
                {
                    if (key != null)
                    {
                        key.SetValue("DisableThumbnailCache", 0, RegistryValueKind.DWord);
                        Console.WriteLine("Armazenamento em cache de miniaturas ativado (padrão).");
                    }
                    else
                    {
                        Console.WriteLine("Chave de registro não encontrada.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao ativar cache de miniaturas: " + ex.Message);
            }
        }
    }
}
