﻿using System;
using System.Diagnostics;

namespace Aplicativos_de_modulos_para_Devs.Modulos.WINDOWS
{
    internal class _7_Desat_Bing
    {
        public static void Executar()
        {
            try
            {
                ExecutarComando(@"reg add ""HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search"" /v BingSearchEnabled /t REG_DWORD /d 0 /f");
                ExecutarComando(@"reg add ""HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search"" /v CortanaEnabled /t REG_DWORD /d 0 /f");

                Console.WriteLine("Bing e Cortana desativados com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao desativar Bing e Cortana: {ex.Message}");
            }
        }

        private static void ExecutarComando(string comando)
        {
            var processo = new Process();
            processo.StartInfo.FileName = "cmd.exe";
            processo.StartInfo.Arguments = $"/c {comando}";
            processo.StartInfo.CreateNoWindow = true;
            processo.StartInfo.UseShellExecute = false;
            processo.Start();
            processo.WaitForExit();
        }
    }
}
